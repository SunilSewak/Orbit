
import { Task, List, FilterState, Recurrence } from "../types";

export const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
});

export const blobToBase64 = (blob: Blob): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
});

export const formatRecurrenceText = (recurrence?: Recurrence | null): string => {
    if (!recurrence?.type) return '';
    
    const interval = recurrence.interval || 1;
    let text = '';
    
    switch (recurrence.type) {
        case 'daily':
            text = interval === 1 ? 'Daily' : `Every ${interval} days`;
            break;
        case 'weekly':
            if (recurrence.daysOfWeek?.length) {
                const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                const dayNames = recurrence.daysOfWeek.map(d => days[d]).join(', ');
                text = `Weekly on ${dayNames}`;
            } else {
                text = interval === 1 ? 'Weekly' : `Every ${interval} weeks`;
            }
            break;
        case 'monthly':
            text = interval === 1 ? 'Monthly' : `Every ${interval} months`;
            if (recurrence.daysOfMonth?.length) {
                text += ` on ${recurrence.daysOfMonth.join(', ')}`;
            }
            break;
        case 'yearly':
            text = interval === 1 ? 'Yearly' : `Every ${interval} years`;
            break;
    }
    
    if (recurrence.until) {
        text += ` until ${new Date(recurrence.until).toLocaleDateString()}`;
    } else if (recurrence.count) {
        text += ` for ${recurrence.count} times`;
    }
    
    return text;
};

export const isTaskVisible = (task: Task, list: List, filters: FilterState): boolean => {
    if (task.subtasks?.some(subtask => isTaskVisible(subtask, list, filters))) return true;
    
    if (filters.status !== 'all') {
        const today = new Date();
        today.setHours(0,0,0,0);
        const taskDue = task.dueDate ? new Date(task.dueDate + "T00:00:00") : null;
        if (taskDue) taskDue.setHours(0,0,0,0);
        
        switch (filters.status) {
            case 'completed': if (!task.completed) return false; break;
            case 'incomplete': if (task.completed) return false; break;
            case 'overdue': if (!taskDue || taskDue >= today || task.completed) return false; break;
            case 'dueToday': if (!taskDue || taskDue.getTime() !== today.getTime()) return false; break;
            case 'dueWeek': {
                const nextWeek = new Date(today);
                nextWeek.setDate(today.getDate() + 7);
                if (!taskDue || taskDue < today || taskDue > nextWeek) return false;
                break;
            }
        }
    }
    
    if (filters.dueDate && task.dueDate !== filters.dueDate) return false;
    
    const effectiveAssignee = task.assignee || list.assignee;
    if (filters.assignee !== 'all' && effectiveAssignee !== filters.assignee) return false;
    
    return true;
};

export const sortTasks = (tasks: Task[], sortOption: string): Task[] => {
    if (!tasks) return [];
    const cloned = [...tasks];
    if (sortOption === 'custom') return cloned;
    
    cloned.sort((a, b) => {
        switch (sortOption) {
            case 'dueDate':
                if (!a.dueDate) return 1;
                if (!b.dueDate) return -1;
                return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
            case 'assignee':
                return (a.assignee || '').localeCompare(b.assignee || '');
            case 'completion':
                return (a.completed ? 1 : 0) - (b.completed ? 1 : 0);
        }
        return 0;
    });
    
    cloned.forEach(task => {
        if (task.subtasks?.length) task.subtasks = sortTasks(task.subtasks, sortOption);
    });
    return cloned;
};

// --- Date Helpers for Calendar ---

export const fmt = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

export const expandRecurringTaskDates = (task: Task): string[] => {
    if (!task.dueDate) return [];
    const results: string[] = [];
    
    const startDate = new Date(task.dueDate + "T00:00:00");
    if (isNaN(startDate.getTime())) return [];

    const recurrence = task.recurrence;
    if (!recurrence || !recurrence.type) return [task.dueDate];
    
    let currentDate = new Date(startDate);
    const untilDate = recurrence.until ? new Date(recurrence.until + "T00:00:00") : null;
    const maxOccurrences = recurrence.count || 365; // Limit to 1 year defaults
    
    for (let i = 0; i < maxOccurrences; i++) {
        if (untilDate && currentDate > untilDate) break;
        
        results.push(fmt(currentDate));
        
        switch (recurrence.type) {
            case 'daily':
                currentDate.setDate(currentDate.getDate() + (recurrence.interval || 1));
                break;
            case 'weekly':
                if (recurrence.daysOfWeek && recurrence.daysOfWeek.length > 0) {
                    let nextDate = new Date(currentDate);
                    let found = false;
                    for (let j = 0; j < 7; j++) {
                        nextDate.setDate(nextDate.getDate() + 1);
                        if (recurrence.daysOfWeek.includes(nextDate.getDay())) {
                            currentDate = new Date(nextDate);
                            found = true;
                            break;
                        }
                    }
                    if (!found) currentDate.setDate(currentDate.getDate() + 7);
                } else {
                    currentDate.setDate(currentDate.getDate() + 7 * (recurrence.interval || 1));
                }
                break;
            case 'monthly':
                currentDate.setMonth(currentDate.getMonth() + (recurrence.interval || 1));
                break;
            case 'yearly':
                currentDate.setFullYear(currentDate.getFullYear() + (recurrence.interval || 1));
                break;
        }
    }
    return results;
};

export const expandTaskDates = (task: Task): string[] => {
    if (task.recurrence) return expandRecurringTaskDates(task);
    
    const start = task.startDate ? new Date(task.startDate + "T00:00:00") : null;
    const end = task.endDate ? new Date(task.endDate + "T00:00:00") : null;

    if (!start || !end) return task.dueDate ? [task.dueDate] : [];
    
    const results: string[] = [];
    let cur = new Date(start);
    while (cur <= end) {
        results.push(fmt(cur));
        cur.setDate(cur.getDate() + 1);
    }
    // Always include due date if outside range
    if (task.dueDate && !results.includes(task.dueDate)) {
        results.push(task.dueDate);
    }
    return results;
};

export const getWeekDates = (d: Date): Date[] => {
    const date = new Date(d);
    const day = date.getDay();
    date.setDate(date.getDate() - day); // Start of week (Sunday)
    
    const arr: Date[] = [];
    for (let i = 0; i < 7; i++) {
        const nd = new Date(date);
        nd.setDate(date.getDate() + i);
        arr.push(nd);
    }
    return arr;
};
