
import React, { useState, useEffect, useCallback } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { 
    auth, loginWithGoogle, logout, loadUserData, saveUserData 
} from './services/firebase';
import { 
    Workspace, FilterState, ViewMode, DraggedTaskInfo, Task, Recurrence, List, RosterData 
} from './types';
import Board from './components/Board';
import CalendarView from './components/CalendarView';
import RosterView from './components/RosterView';
import RecurrencePopup from './components/RecurrencePopup';
import TaskPopup from './components/TaskPopup';
import { Layout, LogOut, Loader2, Calendar as CalIcon, AlertTriangle, X, Copy, ExternalLink, ShieldAlert, RefreshCw, Save, Upload, Download, Trash2, Plus, GripVertical, User, FileSpreadsheet, Settings, FolderHeart } from 'lucide-react';

const App = () => {
    // Auth State
    const [user, setUser] = useState<FirebaseUser | null>(null);
    const [authLoading, setAuthLoading] = useState(true);
    const [configError, setConfigError] = useState<string | null>(null);

    // App Data State
    const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
    const [savedWorkspaces, setSavedWorkspaces] = useState<Workspace[]>([]);
    const [activeWorkspaceId, setActiveWorkspaceId] = useState<string | null>(null);
    // Default assignees updated to user request
    const [assignees, setAssignees] = useState<string[]>(['Pramod', 'Kaushik', 'Prayas', 'Sreenath', 'Sunil', 'Rutuja', 'Vivek', 'Romy', 'Meiraj']);
    const [rosterData, setRosterData] = useState<RosterData>({});
    
    // UI State
    const [viewMode, setViewMode] = useState<ViewMode>('tasks');
    const [filters, setFilters] = useState<FilterState>({ status: 'all', dueDate: '', assignee: 'all' });
    const [sortOption, setSortOption] = useState('custom');
    const [draggedTaskInfo, setDraggedTaskInfo] = useState<DraggedTaskInfo | null>(null);
    const [recurrencePopup, setRecurrencePopup] = useState<{task: Task, listId: string} | null>(null);
    const [popupTask, setPopupTask] = useState<{task: Task, listId: string} | null>(null);
    const [previewImage, setPreviewImage] = useState<any>(null);

    // Modals
    const [isWorkspaceModalOpen, setIsWorkspaceModalOpen] = useState(false);
    const [isManageModalOpen, setIsManageModalOpen] = useState(false);
    const [modalMode, setModalMode] = useState<'blank' | 'load' | 'import'>('blank');
    const [newWorkspaceName, setNewWorkspaceName] = useState('');
    const [selectedTemplateId, setSelectedTemplateId] = useState('');
    const [isAssigneeModalOpen, setIsAssigneeModalOpen] = useState(false);
    const [newAssigneeName, setNewAssigneeName] = useState('');
    
    // Add List Modal
    const [isAddListModalOpen, setIsAddListModalOpen] = useState(false);
    const [addListWorkspaceId, setAddListWorkspaceId] = useState<string | null>(null);
    const [addListMode, setAddListMode] = useState<'blank' | 'template'>('blank');
    const [newListName, setNewListName] = useState('');
    const [selectedListTemplateId, setSelectedListTemplateId] = useState(''); // Workspace ID to choose list from
    const [selectedListIdFromTemplate, setSelectedListIdFromTemplate] = useState(''); 

    // --- Authentication & Data Loading ---
    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged(async (currentUser) => {
            setUser(currentUser);
            if (currentUser) {
                try {
                    const data = await loadUserData(currentUser.uid);
                    if (data) {
                        setWorkspaces(data.workspaces || []);
                        setSavedWorkspaces(data.savedWorkspaces || []);
                        setAssignees(data.assignees || ['Pramod', 'Kaushik', 'Prayas', 'Sreenath', 'Sunil', 'Rutuja', 'Vivek', 'Romy', 'Meiraj']);
                        setRosterData(data.rosterData || {});
                        setActiveWorkspaceId(data.activeWorkspaceId || (data.workspaces?.[0]?.id || null));
                    } else {
                        // Initialize default data for new user
                        const defaultWorkspace: Workspace = {
                            id: Date.now().toString(),
                            name: 'My First Project',
                            lists: [
                                { id: '1', name: 'To Do', tasks: [] },
                                { id: '2', name: 'In Progress', tasks: [] },
                                { id: '3', name: 'Done', tasks: [] }
                            ]
                        };
                        setWorkspaces([defaultWorkspace]);
                        setActiveWorkspaceId(defaultWorkspace.id);
                    }
                } catch (err: any) {
                    console.error("Failed to load data", err);
                    if (err.code === 'permission-denied' || err.message?.includes('permission-denied')) {
                        setConfigError("PERMISSION_DENIED");
                    }
                }
            } else {
                setWorkspaces([]);
                setActiveWorkspaceId(null);
            }
            setAuthLoading(false);
        });
        return () => unsubscribe();
    }, []);

    // --- Persistence ---
    const saveData = async () => {
        if (!user) return;
        try {
            await saveUserData(user.uid, {
                workspaces,
                savedWorkspaces,
                assignees,
                rosterData,
                activeWorkspaceId
            });
            return true;
        } catch (err: any) {
            console.error("Save failed", err);
            if (err.code === 'permission-denied' || err.message?.includes('permission-denied') || err.message?.includes('Missing or insufficient permissions')) {
                setConfigError("PERMISSION_DENIED");
            }
            throw err;
        }
    };

    // Auto-save debouncer
    useEffect(() => {
        if (!user || workspaces.length === 0) return;
        const timer = setTimeout(() => {
            saveData().catch(() => {}); // Swallow error for auto-save
        }, 1000); // Reduced to 1s for better responsiveness
        return () => clearTimeout(timer);
    }, [workspaces, savedWorkspaces, assignees, rosterData, activeWorkspaceId, user]);

    // Manual Save Handler
    const handleManualSave = async () => {
        try {
            await saveData();
            alert("All changes saved to cloud.");
        } catch (e) {
            alert("Error saving data. Please check connection.");
        }
    };

    // --- Auth Handler ---
    const handleLogin = async () => {
        setConfigError(null);
        try {
            await loginWithGoogle();
        } catch (error: any) {
            const errCode = error.code || '';
            const errMsg = error.message || '';
            if (errCode === 'auth/api-key-not-valid' || errMsg.includes('api-key-not-valid')) setConfigError("MISSING_API_KEY");
            else if (errCode === 'auth/unauthorized-domain' || errMsg.includes('unauthorized-domain')) setConfigError("UNAUTHORIZED_DOMAIN");
            else if (errCode !== 'auth/popup-closed-by-user') alert(`Login failed: ${errMsg}`);
        }
    };

    // --- Helpers ---
    const findTask = (data: Workspace[], id: string): Task | null => {
        for(const w of data) {
            for(const l of w.lists) {
                const search = (tasks: Task[]): Task | null => {
                    for(const t of tasks) {
                        if(t.id === id) return t;
                        const res = search(t.subtasks);
                        if(res) return res;
                    }
                    return null;
                }
                const found = search(l.tasks);
                if(found) return found;
            }
        }
        return null;
    };

    const findTaskAndModify = (tasks: Task[], taskId: string, modifyCallback: (t: Task) => Task): Task[] => {
        return tasks.map(task => {
            if (task.id === taskId) return modifyCallback(task);
            if (task.subtasks?.length > 0) return { ...task, subtasks: findTaskAndModify(task.subtasks, taskId, modifyCallback) };
            return task;
        });
    };

    // --- Handlers (CRUD) ---
    const handlers = {
        onUpdateWorkspace: (id: string, patch: Partial<Workspace>) => setWorkspaces(prev => prev.map(w => w.id === id ? { ...w, ...patch } : w)),
        onAddList: (workspaceId: string) => {
            setAddListWorkspaceId(workspaceId);
            setAddListMode('blank');
            setNewListName('');
            setIsAddListModalOpen(true);
        },
        onUpdateList: (listId: string, patch: Partial<List>) => setWorkspaces(prev => prev.map(w => ({ ...w, lists: w.lists.map(l => l.id === listId ? { ...l, ...patch } : l) }))),
        onDeleteList: (listId: string) => { if (confirm("Delete list?")) setWorkspaces(prev => prev.map(w => ({ ...w, lists: w.lists.filter(l => l.id !== listId) }))); },
        onAddTask: (listId: string) => {
            const newTask: Task = { id: Date.now().toString(), text: 'New Task', completed: false, subtasks: [], checklist: [] };
            setWorkspaces(prev => prev.map(w => ({ ...w, lists: w.lists.map(l => l.id === listId ? { ...l, tasks: [...l.tasks, newTask] } : l) })));
        },
        onUpdateTask: (listId: string, taskId: string, patch: Partial<Task>) => {
            setWorkspaces(prev => prev.map(w => ({ ...w, lists: w.lists.map(l => l.id !== listId ? l : { ...l, tasks: findTaskAndModify(l.tasks, taskId, t => ({ ...t, ...patch })) }) })));
        },
        onDeleteTask: (listId: string, taskId: string) => {
            const deleteRecursive = (tasks: Task[]): Task[] => tasks.filter(t => t.id !== taskId).map(t => ({ ...t, subtasks: deleteRecursive(t.subtasks) }));
            setWorkspaces(prev => prev.map(w => ({ ...w, lists: w.lists.map(l => l.id !== listId ? l : { ...l, tasks: deleteRecursive(l.tasks) }) })));
        },
        onAddSubtask: (listId: string, parentId: string) => {
             const newSub: Task = { id: Date.now().toString(), text: 'Subtask', completed: false, subtasks: [], checklist: [] };
             handlers.onUpdateTask(listId, parentId, { subtasks: [...(findTask(workspaces, parentId)?.subtasks || []), newSub] });
        },
        onAddChecklistItem: (listId: string, taskId: string) => {
            const newItem = { id: Date.now().toString(), text: 'New Item', completed: false };
            const t = findTask(workspaces, taskId);
            if(t) handlers.onUpdateTask(listId, taskId, { checklist: [...t.checklist, newItem] });
        },
        onUpdateChecklistItem: (listId: string, taskId: string, itemId: string, patch: any) => {
            const t = findTask(workspaces, taskId);
            if(t) handlers.onUpdateTask(listId, taskId, { checklist: t.checklist.map(i => i.id === itemId ? { ...i, ...patch } : i) });
        },
        onToggleChecklistItem: (listId: string, taskId: string, itemId: string) => {
             const t = findTask(workspaces, taskId);
             if(t) {
                 const item = t.checklist.find(i => i.id === itemId);
                 if(item) handlers.onUpdateTask(listId, taskId, { checklist: t.checklist.map(i => i.id === itemId ? { ...i, completed: !item.completed } : i) });
             }
        },
        onDeleteChecklistItem: (listId: string, taskId: string, itemId: string) => {
            const t = findTask(workspaces, taskId);
            if(t) handlers.onUpdateTask(listId, taskId, { checklist: t.checklist.filter(i => i.id !== itemId) });
        },
        onAttachFile: async (listId: string, taskId: string, file: File) => {
             if (file.size > 5 * 1024 * 1024) { alert('File is too large. Max 5MB.'); return; }
             const reader = new FileReader();
             reader.onload = () => {
                 const newAttachment = { id: Date.now().toString(), name: file.name, type: file.type, data: reader.result as string };
                 const t = findTask(workspaces, taskId);
                 if(t) handlers.onUpdateTask(listId, taskId, { attachments: [...(t.attachments || []), newAttachment] });
             };
             reader.readAsDataURL(file);
        },
        onPasteAttachment: async (listId: string, taskId: string) => {
            try {
                const items = await navigator.clipboard.read();
                const imageItem = items.find(item => item.types.some(type => type.startsWith('image/')));
                if (!imageItem) { alert('No image on clipboard'); return; }
                const blob = await imageItem.getType(imageItem.types.find(t => t.startsWith('image/'))!);
                const reader = new FileReader();
                reader.onload = () => {
                    const newAttachment = { id: Date.now().toString(), name: `Pasted Image ${Date.now()}`, type: blob.type, data: reader.result as string };
                    const t = findTask(workspaces, taskId);
                    if(t) handlers.onUpdateTask(listId, taskId, { attachments: [...(t.attachments || []), newAttachment] });
                };
                reader.readAsDataURL(blob);
            } catch (e) { alert("Clipboard access failed or not supported."); }
        },
        onDeleteAttachment: (listId: string, taskId: string, attachmentId: string) => {
            const t = findTask(workspaces, taskId);
            if(t) handlers.onUpdateTask(listId, taskId, { attachments: t.attachments?.filter(a => a.id !== attachmentId) });
        },
        onPreviewAttachment: (att: any) => {
             if(att.type.startsWith('image/')) setPreviewImage(att);
             else window.open(att.data, '_blank');
        },
        onShowRecurrencePopup: (task: Task, listId: string) => setRecurrencePopup({ task, listId }),
        onSaveAsTemplate: (workspaceId: string) => {
            const ws = workspaces.find(w => w.id === workspaceId);
            if (ws) {
                const name = prompt('Save this workspace configuration as:', ws.name);
                if (name) {
                    const existingIndex = savedWorkspaces.findIndex(sw => sw.name === name);
                    
                    if (existingIndex >= 0) {
                        if (confirm(`A saved workspace named "${name}" already exists. Do you want to overwrite (update) it?`)) {
                            // Update existing
                            setSavedWorkspaces(prev => {
                                const updated = [...prev];
                                updated[existingIndex] = { ...JSON.parse(JSON.stringify(ws)), id: updated[existingIndex].id, name };
                                return updated;
                            });
                            alert(`Saved workspace "${name}" updated successfully.`);
                        } else {
                            // Cancel or different name? For simplicity, we just stop. 
                            // User can click save again to choose a new name.
                        }
                    } else {
                        // Create new
                        const template = { ...JSON.parse(JSON.stringify(ws)), id: Date.now().toString(), name };
                        setSavedWorkspaces(prev => [...prev, template]);
                        alert(`New workspace "${name}" saved.`);
                    }
                }
            }
        },
        onOpenTaskPopup: (task: Task, listId: string) => setPopupTask({ task, listId }),
        // Drag Logic
        onTaskDragStart: (e: React.DragEvent, info: DraggedTaskInfo) => { e.stopPropagation(); setDraggedTaskInfo(info); },
        onTaskDrop: (e: React.DragEvent, target: DraggedTaskInfo) => {
            e.preventDefault(); e.stopPropagation();
            if (!draggedTaskInfo) return;
            const { listId: srcList, taskId: srcTask } = draggedTaskInfo;
            const { listId: tgtList, taskId: tgtTask } = target;
            
            // Simplified: Prevent dragging into self or cross-workspace (implicitly handled by list lookup)
            if (srcTask === tgtTask) { setDraggedTaskInfo(null); return; }

            setWorkspaces(prev => {
                const newState = JSON.parse(JSON.stringify(prev));
                const ws = newState.find((w: Workspace) => w.id === activeWorkspaceId);
                const sList = ws.lists.find((l: List) => l.id === srcList);
                const tList = ws.lists.find((l: List) => l.id === tgtList);

                // Find and remove source task
                let taskObj: Task | null = null;
                const removeRecursively = (tasks: Task[]): Task[] => {
                    const result = [];
                    for(const t of tasks) {
                        if(t.id === srcTask) { taskObj = t; } 
                        else {
                            if(t.subtasks) t.subtasks = removeRecursively(t.subtasks);
                            result.push(t);
                        }
                    }
                    return result;
                }
                sList.tasks = removeRecursively(sList.tasks);
                if (!taskObj) return prev; // Failed to find task

                // Insert target task
                // Check if dropping on a task to make it a child or sibling
                // Simplified: Insert After for now, unless specific logic added
                let inserted = false;
                const insertRecursively = (tasks: Task[]): Task[] => {
                    if (inserted) return tasks;
                    const idx = tasks.findIndex(t => t.id === tgtTask);
                    if (idx !== -1) {
                         // Decide placement based on drop position logic passed from component? 
                         // For simplicity, insert after
                         const newArr = [...tasks];
                         newArr.splice(idx + 1, 0, taskObj!);
                         inserted = true;
                         return newArr;
                    }
                    return tasks.map(t => ({...t, subtasks: insertRecursively(t.subtasks)}));
                }

                // Special case: Dropping into empty list
                if (tList.tasks.length === 0 && !tgtTask) {
                    tList.tasks.push(taskObj);
                } else {
                    tList.tasks = insertRecursively(tList.tasks);
                }

                return newState;
            });
            setDraggedTaskInfo(null);
        },
        draggedTaskInfo
    };

    const onUpdateRoster = (key: string, data: any[][]) => {
        setRosterData(prev => ({
            ...prev,
            [key]: data
        }));
    };

    // --- Workspace Management Handlers ---
    const handleDeleteWorkspace = (id: string) => {
        if (workspaces.length <= 1) {
            alert("You must have at least one workspace.");
            return;
        }
        if (!confirm("Are you sure you want to delete this workspace? This action cannot be undone.")) return;
        
        const newWorkspaces = workspaces.filter(w => w.id !== id);
        setWorkspaces(newWorkspaces);
        
        if (activeWorkspaceId === id) {
            setActiveWorkspaceId(newWorkspaces[0]?.id || null);
        }
    };
    
    // --- Saved Workspace Handlers ---
    const handleUpdateSavedWorkspace = (id: string, patch: Partial<Workspace>) => {
        setSavedWorkspaces(prev => prev.map(w => w.id === id ? { ...w, ...patch } : w));
    };

    const handleDeleteSavedWorkspace = (id: string) => {
        if (!confirm("Are you sure you want to delete this saved workspace template?")) return;
        setSavedWorkspaces(prev => prev.filter(w => w.id !== id));
    };

    // --- List Creation Logic ---
    const handleCreateList = () => {
        if (!addListWorkspaceId) return;

        if (addListMode === 'blank') {
            const name = newListName || "New List";
            setWorkspaces(prev => prev.map(w => w.id === addListWorkspaceId ? { 
                ...w, 
                lists: [...w.lists, { id: Date.now().toString(), name, tasks: [] }] 
            } : w));
        } else if (addListMode === 'template' && selectedListTemplateId && selectedListIdFromTemplate) {
            const templateWs = savedWorkspaces.find(w => w.id === selectedListTemplateId);
            const templateList = templateWs?.lists.find(l => l.id === selectedListIdFromTemplate);
            
            if (templateList) {
                // Deep copy the list and regenerate IDs for tasks to prevent collisions
                const regenerateIds = (tasks: Task[]): Task[] => tasks.map(t => ({
                    ...t,
                    id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                    subtasks: regenerateIds(t.subtasks)
                }));

                const newList: List = {
                    ...JSON.parse(JSON.stringify(templateList)),
                    id: Date.now().toString(),
                    name: newListName || templateList.name, // Use input name or keep template name
                    tasks: regenerateIds(templateList.tasks)
                };

                setWorkspaces(prev => prev.map(w => w.id === addListWorkspaceId ? { 
                    ...w, 
                    lists: [...w.lists, newList] 
                } : w));
            }
        }
        setIsAddListModalOpen(false);
    };


    // --- Modal Logic ---
    const handleCreateWorkspace = () => {
        if (modalMode === 'blank' && newWorkspaceName) {
            const newWs: Workspace = {
                id: Date.now().toString(),
                name: newWorkspaceName,
                lists: [{ id: Date.now().toString() + '1', name: 'To Do', tasks: [] }]
            };
            setWorkspaces([...workspaces, newWs]);
            setActiveWorkspaceId(newWs.id);
        } else if (modalMode === 'load' && selectedTemplateId) {
             const tpl = savedWorkspaces.find(w => w.id === selectedTemplateId);
             if(tpl) {
                 const newWs = { ...JSON.parse(JSON.stringify(tpl)), id: Date.now().toString(), name: `${tpl.name} (Copy)` };
                 setWorkspaces([...workspaces, newWs]);
                 setActiveWorkspaceId(newWs.id);
             }
        }
        setIsWorkspaceModalOpen(false);
        setNewWorkspaceName('');
    };

    const handleManualBackup = () => {
        const data = { workspaces, savedWorkspaces, assignees, rosterData, version: '1.1', date: new Date().toISOString() };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `orbit-backup-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    const handleManualImport = () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = async (e: any) => {
            const file = e.target.files[0];
            if (!file) return;
            try {
                const text = await file.text();
                const json = JSON.parse(text);
                if (json.workspaces) setWorkspaces(json.workspaces);
                if (json.savedWorkspaces) setSavedWorkspaces(json.savedWorkspaces);
                if (json.assignees) setAssignees(json.assignees);
                if (json.rosterData) setRosterData(json.rosterData);
                alert("Import successful!");
            } catch (err) { alert("Invalid backup file."); }
        };
        input.click();
    };

    // --- Render ---

    if (authLoading) return <div className="min-h-screen flex items-center justify-center bg-slate-100"><Loader2 className="animate-spin text-indigo-600 w-10 h-10"/></div>;

    if (!user) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 text-white p-4">
                 <div className="bg-white text-slate-900 p-8 rounded-2xl shadow-2xl max-w-md w-full text-center relative">
                    <h1 className="text-4xl font-bold font-heading mb-4 text-indigo-700">Orbit</h1>
                    <p className="text-slate-600 mb-8">Organize your life with powerful task management.</p>
                    <button onClick={handleLogin} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2">Sign in with Google</button>
                 </div>
                 {configError && (
                     <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                        <div className="bg-white p-6 rounded-lg shadow-xl text-black max-w-md">
                            <h3 className="text-lg font-bold text-red-600 mb-2">Configuration Error</h3>
                            <p className="mb-4">
                                {configError === "UNAUTHORIZED_DOMAIN" ? (
                                    <>
                                        The current domain is not authorized in Firebase. Please add the following domain to your Firebase Console &gt; Authentication &gt; Settings &gt; Authorized Domains:
                                        <br/>
                                        <code className="block bg-slate-100 p-2 mt-2 rounded font-mono text-sm select-all">
                                            {window.location.hostname}
                                        </code>
                                    </>
                                ) : configError}
                            </p>
                            <div className="flex justify-end">
                                <button 
                                    onClick={() => setConfigError(null)}
                                    className="px-4 py-2 bg-slate-200 hover:bg-slate-300 rounded text-slate-800"
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                     </div>
                 )}
            </div>
        );
    }

    const activeWorkspace = workspaces.find(w => w.id === activeWorkspaceId);

    return (
        <div className="flex flex-col h-screen bg-slate-100 text-slate-900 font-sans">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between shadow-sm z-20">
                <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold font-heading text-lg">O</div>
                    <h1 className="text-xl font-bold font-heading hidden md:block">Orbit</h1>
                    <div className="h-6 w-px bg-slate-300 mx-2"></div>
                    <select 
                        value={activeWorkspaceId || ''} 
                        onChange={(e) => setActiveWorkspaceId(e.target.value)}
                        className="bg-slate-100 border-none rounded-md px-3 py-1.5 text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                    >
                        {workspaces.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                    </select>
                    <button 
                        onClick={() => setIsManageModalOpen(true)}
                        className="p-1.5 hover:bg-slate-200 rounded-md text-slate-500"
                        title="Manage Workspaces"
                    >
                        <Settings size={18} />
                    </button>
                </div>
                
                <div className="flex items-center gap-2">
                    {/* View Switcher */}
                    <div className="flex bg-slate-100 rounded-lg p-1 mr-4">
                        <button onClick={() => setViewMode('tasks')} className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${viewMode === 'tasks' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Tasks</button>
                        <button onClick={() => setViewMode('calendar')} className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${viewMode === 'calendar' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Month</button>
                        <button onClick={() => setViewMode('week')} className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${viewMode === 'week' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Week</button>
                        <button onClick={() => setViewMode('today')} className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${viewMode === 'today' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Today</button>
                        <button onClick={() => setViewMode('roster')} className={`px-3 py-1 rounded-md text-sm font-medium transition-all flex items-center gap-1 ${viewMode === 'roster' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>
                            Roster
                        </button>
                    </div>

                    <div className="flex gap-1">
                        <button onClick={() => { setModalMode('blank'); setIsWorkspaceModalOpen(true); }} className="p-2 hover:bg-slate-100 rounded-full" title="New Workspace"><Plus size={20}/></button>
                        <button onClick={handleManualSave} className="p-2 hover:bg-slate-100 rounded-full text-indigo-600" title="Save to Cloud"><Save size={20}/></button>
                        <button onClick={handleManualBackup} className="p-2 hover:bg-slate-100 rounded-full" title="Backup to File"><Download size={20}/></button>
                        <button onClick={handleManualImport} className="p-2 hover:bg-slate-100 rounded-full" title="Restore from File"><Upload size={20}/></button>
                        <button onClick={() => setIsAssigneeModalOpen(true)} className="p-2 hover:bg-slate-100 rounded-full" title="Manage Assignees"><User size={20}/></button>
                        <button onClick={logout} className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-full" title="Sign Out"><LogOut size={20}/></button>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="flex-grow overflow-hidden p-4 relative">
                {!activeWorkspace ? (
                    <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-4">
                        <p>No workspace selected</p>
                        <button onClick={() => { setModalMode('blank'); setIsWorkspaceModalOpen(true); }} className="bg-indigo-600 text-white px-4 py-2 rounded">Create Workspace</button>
                    </div>
                ) : (
                    <>
                        {viewMode === 'tasks' && (
                            <Board 
                                workspace={activeWorkspace}
                                assignees={assignees}
                                filters={filters}
                                sortOption={sortOption}
                                handlers={handlers}
                            />
                        )}
                        {viewMode === 'calendar' && (
                            <CalendarView 
                                workspaces={workspaces}
                                activeWorkspaceId={activeWorkspaceId}
                                viewMode='calendar'
                                handlers={handlers}
                                filters={filters}
                                assignees={assignees}
                            />
                        )}
                         {viewMode === 'week' && (
                            <CalendarView 
                                workspaces={workspaces}
                                activeWorkspaceId={activeWorkspaceId}
                                viewMode='week'
                                handlers={handlers}
                                filters={filters}
                                assignees={assignees}
                            />
                        )}
                         {viewMode === 'today' && (
                            <CalendarView 
                                workspaces={workspaces}
                                activeWorkspaceId={activeWorkspaceId}
                                viewMode='today'
                                handlers={handlers}
                                filters={filters}
                                assignees={assignees}
                            />
                        )}
                        {viewMode === 'roster' && (
                            <RosterView 
                                rosterData={rosterData}
                                onUpdateRoster={onUpdateRoster}
                                assignees={assignees}
                            />
                        )}
                    </>
                )}
            </main>

            {/* Modals */}
            {isWorkspaceModalOpen && (
                <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-xl p-6 w-[400px] shadow-2xl">
                        <h2 className="text-xl font-bold mb-4">Workspace Actions</h2>
                        <div className="flex gap-4 mb-4 border-b">
                            <button onClick={() => setModalMode('blank')} className={`pb-2 ${modalMode === 'blank' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-slate-500'}`}>New</button>
                            <button onClick={() => setModalMode('load')} className={`pb-2 ${modalMode === 'load' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-slate-500'}`}>Load Saved Workspace</button>
                        </div>
                        
                        {modalMode === 'blank' ? (
                            <input value={newWorkspaceName} onChange={e => setNewWorkspaceName(e.target.value)} placeholder="Workspace Name" className="w-full border p-2 rounded mb-4"/>
                        ) : (
                            <div className="space-y-2 mb-4 max-h-40 overflow-y-auto">
                                {savedWorkspaces.length === 0 && <p className="text-sm text-slate-500">No saved workspaces found.</p>}
                                {savedWorkspaces.map(w => (
                                    <div key={w.id} className="flex justify-between items-center p-2 hover:bg-slate-50 rounded cursor-pointer" onClick={() => setSelectedTemplateId(w.id)}>
                                        <div className="flex items-center gap-2">
                                            <input type="radio" checked={selectedTemplateId === w.id} onChange={() => setSelectedTemplateId(w.id)} />
                                            <span>{w.name}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                        
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setIsWorkspaceModalOpen(false)} className="px-4 py-2 text-slate-600">Cancel</button>
                            <button onClick={handleCreateWorkspace} className="px-4 py-2 bg-indigo-600 text-white rounded">Create</button>
                        </div>
                    </div>
                </div>
            )}

            {isAddListModalOpen && (
                <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-xl p-6 w-[400px] shadow-2xl">
                        <h2 className="text-xl font-bold mb-4">Add List</h2>
                        <div className="flex gap-4 mb-4 border-b">
                            <button onClick={() => setAddListMode('blank')} className={`pb-2 ${addListMode === 'blank' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-slate-500'}`}>Blank</button>
                            <button onClick={() => setAddListMode('template')} className={`pb-2 ${addListMode === 'template' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-slate-500'}`}>From Saved Workspace</button>
                        </div>

                        {addListMode === 'blank' ? (
                            <input value={newListName} onChange={e => setNewListName(e.target.value)} placeholder="List Name" className="w-full border p-2 rounded mb-4"/>
                        ) : (
                             <div className="space-y-4 mb-4">
                                <div>
                                    <label className="text-sm font-semibold block mb-1">Select Saved Workspace</label>
                                    <select 
                                        value={selectedListTemplateId} 
                                        onChange={e => { setSelectedListTemplateId(e.target.value); setSelectedListIdFromTemplate(''); }}
                                        className="w-full border p-2 rounded"
                                    >
                                        <option value="">-- Choose Workspace --</option>
                                        {savedWorkspaces.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                                    </select>
                                </div>
                                {selectedListTemplateId && (
                                    <div>
                                        <label className="text-sm font-semibold block mb-1">Select List</label>
                                        <select 
                                            value={selectedListIdFromTemplate} 
                                            onChange={e => setSelectedListIdFromTemplate(e.target.value)}
                                            className="w-full border p-2 rounded"
                                        >
                                            <option value="">-- Choose List --</option>
                                            {savedWorkspaces.find(w => w.id === selectedListTemplateId)?.lists.map(l => (
                                                <option key={l.id} value={l.id}>{l.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                                <input value={newListName} onChange={e => setNewListName(e.target.value)} placeholder="New Name (Optional)" className="w-full border p-2 rounded"/>
                            </div>
                        )}

                        <div className="flex justify-end gap-2">
                            <button onClick={() => setIsAddListModalOpen(false)} className="px-4 py-2 text-slate-600">Cancel</button>
                            <button onClick={handleCreateList} className="px-4 py-2 bg-indigo-600 text-white rounded">Add List</button>
                        </div>
                    </div>
                </div>
            )}

            {isManageModalOpen && (
                <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-xl p-6 w-[550px] shadow-2xl max-h-[80vh] flex flex-col">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-xl font-bold font-heading">Manage Workspaces</h2>
                            <button onClick={() => setIsManageModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
                        </div>
                        
                        <div className="overflow-y-auto flex-grow pr-2 space-y-6">
                            {/* Active Workspaces Section */}
                            <div>
                                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Active Sessions</h3>
                                <div className="space-y-3">
                                    {workspaces.map(w => (
                                        <div key={w.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100 group">
                                            <div className={`w-2 h-8 rounded-full ${w.id === activeWorkspaceId ? 'bg-indigo-500' : 'bg-slate-300'}`}></div>
                                            <input 
                                                value={w.name}
                                                onChange={(e) => handlers.onUpdateWorkspace(w.id, { name: e.target.value })}
                                                className="flex-grow bg-transparent font-medium text-slate-700 outline-none focus:border-b border-indigo-300"
                                            />
                                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                {w.id !== activeWorkspaceId && (
                                                    <button 
                                                        onClick={() => { setActiveWorkspaceId(w.id); setIsManageModalOpen(false); }}
                                                        className="p-1.5 hover:bg-white rounded text-indigo-600 text-xs font-bold"
                                                    >
                                                        Switch
                                                    </button>
                                                )}
                                                <button 
                                                    onClick={() => handleDeleteWorkspace(w.id)}
                                                    className="p-1.5 hover:bg-red-100 text-slate-400 hover:text-red-500 rounded transition-colors"
                                                    title="Delete Workspace"
                                                >
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Saved Workspaces Section */}
                            <div>
                                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Saved Workspaces</h3>
                                {savedWorkspaces.length === 0 ? (
                                    <p className="text-slate-400 text-sm italic">No saved workspaces yet.</p>
                                ) : (
                                    <div className="space-y-3">
                                        {savedWorkspaces.map(w => (
                                            <div key={w.id} className="flex items-center gap-3 p-3 bg-indigo-50/50 rounded-lg border border-indigo-100 group">
                                                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg">
                                                    <FolderHeart size={16} />
                                                </div>
                                                <input
                                                    value={w.name}
                                                    onChange={(e) => handleUpdateSavedWorkspace(w.id, { name: e.target.value })}
                                                    className="flex-grow bg-transparent font-medium text-slate-700 outline-none focus:border-b border-indigo-300"
                                                    placeholder="Template Name"
                                                />
                                                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <button
                                                        onClick={() => handleDeleteSavedWorkspace(w.id)}
                                                        className="p-1.5 hover:bg-red-100 text-slate-400 hover:text-red-500 rounded transition-colors"
                                                        title="Delete Template"
                                                    >
                                                        <Trash2 size={16} />
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between items-center">
                             <button 
                                onClick={() => { setIsManageModalOpen(false); setModalMode('blank'); setIsWorkspaceModalOpen(true); }}
                                className="flex items-center gap-2 text-indigo-600 font-semibold hover:bg-indigo-50 px-3 py-2 rounded-lg transition-colors"
                            >
                                <Plus size={18} /> Create New Workspace
                            </button>
                            <button onClick={() => setIsManageModalOpen(false)} className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900">Done</button>
                        </div>
                    </div>
                </div>
            )}

            {isAssigneeModalOpen && (
                <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                     <div className="bg-white rounded-xl p-6 w-[350px] shadow-2xl">
                        <h2 className="text-xl font-bold mb-4">Manage Assignees</h2>
                        <div className="space-y-2 mb-4 max-h-60 overflow-y-auto">
                            {assignees.map(a => (
                                <div key={a} className="flex justify-between bg-slate-50 p-2 rounded">
                                    <span>{a}</span>
                                    <button onClick={() => setAssignees(assignees.filter(x => x !== a))} className="text-red-500"><Trash2 size={16}/></button>
                                </div>
                            ))}
                        </div>
                        <div className="flex gap-2">
                            <input value={newAssigneeName} onChange={e => setNewAssigneeName(e.target.value)} placeholder="New Name" className="border p-2 rounded flex-grow"/>
                            <button onClick={() => { if(newAssigneeName) { setAssignees([...assignees, newAssigneeName]); setNewAssigneeName(''); }}} className="bg-indigo-600 text-white p-2 rounded"><Plus/></button>
                        </div>
                        <button onClick={() => setIsAssigneeModalOpen(false)} className="mt-4 w-full bg-slate-200 py-2 rounded">Close</button>
                     </div>
                </div>
            )}

            {recurrencePopup && (
                <RecurrencePopup 
                    task={recurrencePopup.task}
                    onClose={() => setRecurrencePopup(null)}
                    onSave={(rec) => {
                        handlers.onUpdateTask(recurrencePopup.listId, recurrencePopup.task.id, { recurrence: rec });
                    }}
                />
            )}
            
            {popupTask && (
                <TaskPopup
                    task={popupTask.task}
                    listId={popupTask.listId}
                    assignees={assignees}
                    onUpdate={handlers.onUpdateTask}
                    onClose={() => setPopupTask(null)}
                />
            )}
            
            {previewImage && (
                <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={() => setPreviewImage(null)}>
                    <img src={previewImage.data} alt="Preview" className="max-w-full max-h-full rounded-lg shadow-2xl" />
                </div>
            )}
        </div>
    );
};

export default App;
