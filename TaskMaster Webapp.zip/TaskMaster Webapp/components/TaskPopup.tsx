import React, { useState, useEffect } from 'react';
import { Task } from '../types';

interface TaskPopupProps {
    task: Task;
    listId: string;
    assignees: string[];
    onUpdate: (listId: string, taskId: string, patch: Partial<Task>) => void;
    onClose: () => void;
}

const TaskPopup: React.FC<TaskPopupProps> = ({ task, listId, assignees, onUpdate, onClose }) => {
    // Local state to manage inputs before blur/save
    const [text, setText] = useState(task.text);
    const [dueDate, setDueDate] = useState(task.dueDate || '');
    const [completed, setCompleted] = useState(task.completed);
    const [assignee, setAssignee] = useState(task.assignee || '');

    // Sync local state if prop changes (rare in this modal context, but good practice)
    useEffect(() => {
        setText(task.text);
        setDueDate(task.dueDate || '');
        setCompleted(task.completed);
        setAssignee(task.assignee || '');
    }, [task]);

    const handleSave = (patch: Partial<Task>) => {
        onUpdate(listId, task.id, patch);
    };

    return (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-[400px] shadow-xl space-y-4">
                <input
                    type="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    onBlur={() => handleSave({ text })}
                    className="w-full border p-2 rounded font-semibold text-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Task Name"
                />
                
                {/* Assignee Selection */}
                 <div className="flex flex-col">
                    <label className="text-xs font-bold text-slate-500 mb-1">Assignee</label>
                    <select
                        value={assignee}
                        onChange={(e) => {
                            setAssignee(e.target.value);
                            handleSave({ assignee: e.target.value });
                        }}
                        className="w-full border p-2 rounded text-sm bg-white focus:ring-1 focus:ring-indigo-500 outline-none"
                    >
                        <option value="">Unassigned</option>
                        {assignees.map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                </div>

                <div className="flex flex-col">
                    <label className="text-xs font-bold text-slate-500 mb-1">Due Date</label>
                    <input
                        type="date"
                        value={dueDate}
                        onChange={(e) => {
                            setDueDate(e.target.value);
                            handleSave({ dueDate: e.target.value });
                        }}
                        className="border p-2 rounded text-sm w-full"
                    />
                </div>

                <label className="flex items-center gap-2 cursor-pointer bg-slate-50 p-2 rounded hover:bg-slate-100">
                    <input
                        type="checkbox"
                        checked={completed}
                        onChange={(e) => {
                            setCompleted(e.target.checked);
                            handleSave({ completed: e.target.checked });
                        }}
                        className="w-5 h-5 text-indigo-600 rounded"
                    />
                    <span className="font-medium text-slate-700">Completed</span>
                </label>

                <button
                    onClick={onClose}
                    className="w-full bg-indigo-600 text-white p-2 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
                >
                    Close
                </button>
            </div>
        </div>
    );
};

export default TaskPopup;