
import React, { useState, useRef } from 'react';
import { RosterData } from '../types';
import { Upload, Download, ChevronLeft, ChevronRight, FileSpreadsheet, Calendar, Filter, X } from 'lucide-react';

interface RosterViewProps {
    rosterData: RosterData;
    onUpdateRoster: (key: string, data: any[][]) => void;
    assignees: string[];
}

const MONTHS = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];

const RosterView: React.FC<RosterViewProps> = ({ rosterData, onUpdateRoster, assignees }) => {
    const today = new Date();
    const [year, setYear] = useState(today.getFullYear());
    const [month, setMonth] = useState(today.getMonth()); // 0-indexed
    const [filterDate, setFilterDate] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const rosterKey = `${year}-${String(month + 1).padStart(2, '0')}`;
    const currentData = rosterData[rosterKey] || [];

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (evt) => {
            const buffer = evt.target?.result;
            // Use raw: false to get the formatted strings from Excel (e.g. "Mon, Dec 01" instead of 46023)
            const wb = (window as any).XLSX.read(buffer, { type: 'array' });
            const wsname = wb.SheetNames[0];
            const ws = wb.Sheets[wsname];
            
            const data = (window as any).XLSX.utils.sheet_to_json(ws, { 
                header: 1, 
                raw: false, 
                defval: "" 
            });
            onUpdateRoster(rosterKey, data);
        };
        reader.readAsArrayBuffer(file);
        
        // Reset input
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleDownloadTemplate = () => {
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const data = [];
        
        // Title Row
        data.push([`Roster Schedule - ${MONTHS[month]} ${year}`]);
        // Empty Row
        data.push([]);
        
        // Header Row - Use assignees to create the exact team grid (Date | Person1 | Person2...)
        const headers = ["Date", ...assignees];
        data.push(headers);

        // Data Rows
        for (let d = 1; d <= daysInMonth; d++) {
            const dateObj = new Date(year, month, d);
            // Matches format: "01 December 2025"
            const dateStr = dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
            
            const row = [dateStr, ...assignees.map(() => "")];
            data.push(row);
        }

        const wb = (window as any).XLSX.utils.book_new();
        const ws = (window as any).XLSX.utils.aoa_to_sheet(data);
        
        // Set column widths
        const wscols = [
            { wch: 12 }, // Date - Reduced Width
            ...assignees.map(() => ({ wch: 14 })) // Names - Set to 14 as requested
        ];
        ws['!cols'] = wscols;

        (window as any).XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
        (window as any).XLSX.writeFile(wb, `Roster_${MONTHS[month]}_${year}.xlsx`);
    };

    const changeMonth = (delta: number) => {
        let newMonth = month + delta;
        let newYear = year;
        if (newMonth > 11) {
            newMonth = 0;
            newYear++;
        } else if (newMonth < 0) {
            newMonth = 11;
            newYear--;
        }
        setMonth(newMonth);
        setYear(newYear);
        // Clear specific date filter when navigating months manually
        setFilterDate('');
    };

    const handleDateFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        setFilterDate(val);
        if (val) {
            // val is YYYY-MM-DD
            const [y, m, d] = val.split('-').map(Number);
            if (y && m) {
                setYear(y);
                setMonth(m - 1); // 0-indexed
            }
        }
    };

    const clearFilter = () => {
        setFilterDate('');
    };

    // Attempt to find the main header row (starts with "Date")
    const headerRowIndex = currentData.findIndex((row: any[]) => 
        row && row[0] && String(row[0]).trim().toLowerCase().includes('date')
    );
    const effectiveHeaderIdx = headerRowIndex >= 0 ? headerRowIndex : 0;

    // Filter Logic
    const dataRows = currentData.slice(effectiveHeaderIdx + 1);
    const filteredRows = dataRows.filter((row: any[]) => {
        if (!filterDate) return true;
        
        const cellValue = row[0];
        if (cellValue === undefined || cellValue === null) return false;
        
        const cellString = String(cellValue).trim();
        
        // Target Filter Date Components
        const [fy, fm, fd] = filterDate.split('-').map(Number);
        
        // 1. Try parsing cell as a Date object (handles "12/01/2025", "Dec 1 2025", etc.)
        const cellDate = new Date(cellString);
        if (!isNaN(cellDate.getTime())) {
            // Check if matches filter date
            // Note: Use local time components match
            if (cellDate.getFullYear() === fy && cellDate.getMonth() === (fm - 1) && cellDate.getDate() === fd) {
                return true;
            }
        }

        // 2. Try exact string match against the generated template format (en-GB)
        const filterObj = new Date(fy, fm - 1, fd);
        const expectedFormat = filterObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
        
        if (cellString.toLowerCase() === expectedFormat.toLowerCase()) return true;

        // 3. Fallback: simple string includes
        return cellString.includes(filterDate) || cellString === filterDate;
    });

    return (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 h-full flex flex-col overflow-hidden">
            {/* Toolbar */}
            <div className="p-4 border-b border-slate-200 flex flex-wrap gap-4 justify-between items-center bg-white z-10">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 text-indigo-800">
                        <FileSpreadsheet size={24} />
                        <h2 className="text-2xl font-bold font-heading">Roster / Schedule</h2>
                    </div>
                    
                    <div className="flex gap-1 bg-slate-100 rounded-lg p-1 items-center">
                        <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-white rounded shadow-sm"><ChevronLeft size={20}/></button>
                        <span className="px-4 font-bold text-slate-700 w-32 text-center">{MONTHS[month]} {year}</span>
                        <button onClick={() => changeMonth(1)} className="p-1 hover:bg-white rounded shadow-sm"><ChevronRight size={20}/></button>
                    </div>

                    {/* Date Filter */}
                    <div className="flex items-center gap-2 bg-slate-50 p-1 rounded-lg border border-slate-200 ml-4">
                        <div className="pl-2 text-slate-400"><Filter size={14} /></div>
                        <input 
                            type="date" 
                            value={filterDate}
                            onChange={handleDateFilterChange}
                            className="bg-transparent border-none text-sm text-slate-700 focus:ring-0 outline-none"
                            placeholder="Filter Date"
                        />
                        {filterDate && (
                            <button onClick={clearFilter} className="p-1 hover:bg-slate-200 rounded-full text-slate-500">
                                <X size={14} />
                            </button>
                        )}
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileUpload} 
                        className="hidden" 
                        accept=".xlsx, .xls"
                    />
                    <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm font-medium"
                    >
                        <Upload size={18} />
                        Upload Excel
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="flex-grow overflow-auto bg-slate-50 relative">
                {currentData.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <FileSpreadsheet size={64} className="mb-4 opacity-20" />
                        <p className="text-lg font-medium">No roster data for {MONTHS[month]} {year}</p>
                        <p className="text-sm mt-2">Upload an Excel file to view the schedule.</p>
                        <button onClick={handleDownloadTemplate} className="text-indigo-600 text-sm font-medium hover:underline mt-2">Download monthly template</button>
                    </div>
                ) : (
                    <div className="min-w-max">
                        <table className="border-collapse w-full bg-white text-xs">
                            <thead className="sticky top-0 z-20 shadow-sm">
                                {/* Pre-header rows (e.g. Month/Year titles) */}
                                {currentData.slice(0, effectiveHeaderIdx).map((row: any[], rIdx: number) => (
                                    <tr key={`pre-${rIdx}`} className="bg-yellow-50/50">
                                        {row.map((cell: any, cIdx: number) => (
                                            <td key={cIdx} className="border-b border-r border-green-600/30 border-dashed px-2 py-1 text-slate-500 italic">
                                                {String(cell ?? "")}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                                {/* Main Header Row */}
                                <tr className="bg-[#FCE883]">
                                    {currentData[effectiveHeaderIdx]?.map((cell: any, cIdx: number) => (
                                        <th 
                                            key={cIdx} 
                                            className={`border-b border-r border-green-600 border-dashed px-3 py-2 font-bold text-slate-800 whitespace-nowrap bg-[#FCE883] ${cIdx === 0 ? 'sticky left-0 z-30 outline outline-1 outline-green-600/20 text-left' : 'min-w-[100px] text-center'}`}
                                        >
                                            {String(cell ?? "")}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {filteredRows.length > 0 ? (
                                    filteredRows.map((row: any[], rIdx: number) => {
                                        // Determine if Sunday
                                        let isSunday = false;
                                        if (row[0]) {
                                            try {
                                                const d = new Date(String(row[0]));
                                                if (!isNaN(d.getTime()) && d.getDay() === 0) {
                                                    isSunday = true;
                                                }
                                            } catch(e) {}
                                        }

                                        return (
                                            <tr key={rIdx} className={`transition-colors ${isSunday ? 'bg-slate-200 hover:bg-slate-300' : 'hover:bg-slate-50'}`}>
                                                {row.map((cell: any, cIdx: number) => {
                                                    const isDateCol = cIdx === 0;
                                                    const baseClasses = "border-b border-r border-green-400 border-dashed px-3 py-1.5 whitespace-nowrap";
                                                    const colClasses = isDateCol 
                                                        ? `font-bold ${isSunday ? 'bg-slate-200' : 'bg-[#FFF8DC]'} text-slate-900 sticky left-0 z-10 text-left` 
                                                        : "text-slate-700 min-w-[100px] text-center";
                                                    
                                                    return (
                                                        <td 
                                                            key={cIdx} 
                                                            className={`${baseClasses} ${colClasses}`}
                                                        >
                                                            {String(cell ?? "")}
                                                        </td>
                                                    );
                                                })}
                                            </tr>
                                        );
                                    })
                                ) : (
                                    <tr>
                                        <td colSpan={100} className="p-8 text-center text-slate-400 italic">
                                            No rows match the date filter.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RosterView;
