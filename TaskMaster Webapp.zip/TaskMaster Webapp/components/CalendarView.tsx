
import React, { useMemo, useState, useEffect } from 'react';
import { Workspace, Task, CalendarTask, ViewMode, FilterState, List } from '../types';
import { ChevronLeft, ChevronRight, RefreshCw, Calendar as CalendarIcon } from 'lucide-react';
import { expandTaskDates, expandRecurringTaskDates, fmt, getWeekDates, formatRecurrenceText } from '../utils/helpers';

interface CalendarViewProps {
    workspaces: Workspace[];
    activeWorkspaceId: string | null;
    viewMode: ViewMode;
    handlers: any;
    filters: FilterState;
    assignees: string[];
}

const LIST_COLORS = ['bg-indigo-600', 'bg-blue-600', 'bg-green-600', 'bg-purple-600', 'bg-rose-600', 'bg-orange-600'];
const getListColor = (index: number) => LIST_COLORS[index % LIST_COLORS.length];
const getTaskColor = (task: CalendarTask, listIndex: number) => {
    const baseColor = LIST_COLORS[listIndex % LIST_COLORS.length];
    if (task.completed) {
        return 'bg-slate-200 text-slate-500 line-through';
    }
    // Extract color name to make a lighter bg for text
    return `${baseColor.replace('bg-', 'text-').replace('600', '700')} bg-white border border-current`;
};

const CalendarView: React.FC<CalendarViewProps> = ({ workspaces, activeWorkspaceId, viewMode, handlers, filters, assignees }) => {
    const [date, setDate] = useState(new Date());
    const [filter, setFilter] = useState<'active' | 'all'>('active');
    const [assigneeFilter, setAssigneeFilter] = useState<string>('all');
    const [calendarDragTask, setCalendarDragTask] = useState<{taskId: string, listId: string} | null>(null);

    const activeWorkspace = workspaces.find(w => w.id === activeWorkspaceId);

    // --- Helpers ---
    const isSameDay = (d1: Date, d2: Date) => fmt(d1) === fmt(d2);
    const today = new Date();

    const findListIndexOfTask = (ws: Workspace | undefined, taskId: string): number => {
        if(!ws) return 0;
        for (let i = 0; i < ws.lists.length; i++) {
            const findInTasks = (tasks: Task[]): boolean => {
                for(const t of tasks) {
                    if(t.id === taskId) return true;
                    if(t.subtasks && findInTasks(t.subtasks)) return true;
                }
                return false;
            }
            if(findInTasks(ws.lists[i].tasks)) return i;
        }
        return 0;
    }

    // --- Data Processing ---
    const { tasksByDate, unscheduledTasks, listSpans } = useMemo(() => {
        const map: Record<string, CalendarTask[]> = {};
        const unscheduled: CalendarTask[] = [];
        const spans: { id: string, name: string, startDate: string, endDate: string }[] = [];

        const targetWorkspaces = (filter === 'active' && activeWorkspaceId) 
            ? workspaces.filter(w => w.id === activeWorkspaceId) 
            : workspaces;

        const processTask = (task: Task, ws: Workspace, list: List) => {
            const effectiveAssignee = task.assignee || list.assignee || 'Unassigned';

            // --- Apply Filters ---
            
            // Status Filter (Global)
            if (filters.status !== 'all') {
                const today = new Date();
                today.setHours(0,0,0,0);
                const taskDue = task.dueDate ? new Date(task.dueDate + "T00:00:00") : null;
                if (taskDue) taskDue.setHours(0,0,0,0);
                
                switch (filters.status) {
                    case 'completed': if (!task.completed) return; break;
                    case 'incomplete': if (task.completed) return; break;
                    case 'overdue': 
                        if (!taskDue || taskDue >= today || task.completed) return; 
                        break;
                    case 'dueToday': 
                        if (!taskDue || taskDue.getTime() !== today.getTime()) return; 
                        break;
                    case 'dueWeek': {
                        const nextWeek = new Date(today);
                        nextWeek.setDate(today.getDate() + 7);
                        if (!taskDue || taskDue < today || taskDue > nextWeek) return;
                        break;
                    }
                }
            }

            // Assignee Filter (Global)
            if (filters.assignee !== 'all' && effectiveAssignee !== filters.assignee) return;

            // Assignee Filter (Local Calendar)
            if (assigneeFilter !== 'all' && effectiveAssignee !== assigneeFilter) return;

            // Date Expansion
            const dates = expandTaskDates(task);
            
            // Due Date Filter
            if (filters.dueDate && !dates.includes(filters.dueDate)) return;

            const calendarTask: CalendarTask = {
                ...task,
                _workspaceId: ws.id,
                _workspaceName: ws.name,
                _listName: list.name,
                _listId: list.id,
                _assignee: effectiveAssignee
            };

            if (dates.length === 0) {
                 unscheduled.push(calendarTask);
            } else {
                dates.forEach(d => {
                    if (!map[d]) map[d] = [];
                    map[d].push(calendarTask);
                });
            }

            if (task.subtasks) {
                task.subtasks.forEach(st => processTask(st, ws, list));
            }
        };

        targetWorkspaces.forEach(ws => {
            ws.lists.forEach(list => {
                if (list.startDate && list.endDate) {
                    spans.push({ id: list.id, name: list.name, startDate: list.startDate, endDate: list.endDate });
                }
                list.tasks.forEach(task => {
                    processTask(task, ws, list);
                });
            });
        });

        // Default stable sort: By List Name then Task Text
        const sorter = (a: CalendarTask, b: CalendarTask) => {
            const listCompare = a._listName.localeCompare(b._listName);
            if (listCompare !== 0) return listCompare;
            return a.text.localeCompare(b.text);
        };

        Object.keys(map).forEach(key => map[key].sort(sorter));
        unscheduled.sort(sorter);

        return { tasksByDate: map, unscheduledTasks: unscheduled, listSpans: spans };
    }, [workspaces, activeWorkspaceId, filter, assigneeFilter, filters]);

    // --- Drag Handlers ---
    const onDragStart = (e: React.DragEvent, task: CalendarTask) => {
        e.stopPropagation();
        setCalendarDragTask({ taskId: task.id, listId: task._listId });
    };

    const onDropOnDate = (dateStr: string) => {
        if (!calendarDragTask) return;
        handlers.onUpdateTask(calendarDragTask.listId, calendarDragTask.taskId, { dueDate: dateStr });
        setCalendarDragTask(null);
    };

    // --- Click Handler ---
    const onTaskClick = (e: React.MouseEvent, t: CalendarTask) => {
        e.stopPropagation();
        if (handlers.onOpenTaskPopup) {
            handlers.onOpenTaskPopup(t, t._listId);
        }
    };

    // --- Renderers ---
    
    const renderSidebar = () => (
        <div className="w-64 bg-slate-50 border-l border-slate-200 p-4 overflow-y-auto flex-shrink-0 hidden lg:block">
             <h3 className="font-bold text-slate-700 mb-4">Unscheduled Tasks</h3>
             {unscheduledTasks.length === 0 ? (
                 <p className="text-slate-400 text-sm">No unscheduled tasks.</p>
             ) : (
                 <ul className="space-y-2">
                     {unscheduledTasks.map(t => (
                         <li 
                            key={t.id}
                            draggable
                            onDragStart={(e) => onDragStart(e, t)}
                            onClick={(e) => onTaskClick(e, t)}
                            className="bg-white p-2 rounded shadow-sm border border-slate-200 cursor-pointer hover:border-indigo-300 hover:shadow-md transition-all"
                         >
                             <div className="text-sm font-medium text-slate-800">
                                 <span className="font-bold">{t._listName}:</span> {t.text}
                             </div>
                             <div className="text-xs text-slate-500 mt-1">({t._assignee})</div>
                         </li>
                     ))}
                 </ul>
             )}
        </div>
    );

    const renderMonthView = () => {
        const year = date.getFullYear();
        const month = date.getMonth();
        const firstDay = new Date(year, month, 1);
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const startDay = firstDay.getDay(); 
        const weeks: (Date | null)[][] = [];
        let currentWeek: (Date | null)[] = [];

        for (let i = 0; i < startDay; i++) currentWeek.push(null);
        for (let day = 1; day <= daysInMonth; day++) {
            currentWeek.push(new Date(year, month, day));
            if (currentWeek.length === 7) { weeks.push(currentWeek); currentWeek = []; }
        }
        if (currentWeek.length > 0) { while (currentWeek.length < 7) currentWeek.push(null); weeks.push(currentWeek); }

        return (
            <div className="flex-grow flex flex-col overflow-hidden">
                <div className="grid grid-cols-7 gap-px bg-slate-200 border-b border-slate-200">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                        <div key={d} className="bg-white py-2 text-center text-sm font-semibold text-slate-600">{d}</div>
                    ))}
                </div>
                <div className="flex-grow overflow-y-auto bg-slate-100 grid grid-rows-5">
                    {weeks.map((week, wIdx) => (
                        <div key={wIdx} className="grid grid-cols-7 gap-px min-h-[120px]">
                            {week.map((day, dIdx) => {
                                if (!day) return <div key={dIdx} className="bg-slate-50/50"></div>;
                                const dateKey = fmt(day);
                                const tasks = tasksByDate[dateKey] || [];
                                const isToday = isSameDay(day, today);
                                const activeLists = listSpans.filter(l => dateKey >= l.startDate && dateKey <= l.endDate);

                                return (
                                    <div 
                                        key={dateKey} 
                                        onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add('bg-indigo-50'); }}
                                        onDragLeave={(e) => e.currentTarget.classList.remove('bg-indigo-50')}
                                        onDrop={(e) => { e.preventDefault(); e.currentTarget.classList.remove('bg-indigo-50'); onDropOnDate(dateKey); }}
                                        onClick={() => {
                                            // Handle clicking empty space
                                        }}
                                        className={`bg-white p-1 flex flex-col hover:bg-slate-50 transition-colors ${isToday ? 'bg-yellow-50' : ''}`}
                                    >
                                        <div className="flex justify-between items-start">
                                            <span className={`text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center ${isToday ? 'bg-indigo-600 text-white' : 'text-slate-700'}`}>
                                                {day.getDate()}
                                            </span>
                                            {activeLists.length > 0 && <div className="text-[10px] text-orange-500 font-bold">●</div>}
                                        </div>
                                        <div className="flex-grow overflow-y-auto mt-1 space-y-1 scrollbar-hide">
                                            {activeLists.map(l => (
                                                <div key={l.id} className="text-[9px] bg-orange-100 text-orange-700 px-1 rounded truncate font-medium border border-orange-200">
                                                    {l.name}
                                                </div>
                                            ))}
                                            {tasks.map(t => {
                                                const ws = workspaces.find(w => w.id === t._workspaceId);
                                                const listIdx = findListIndexOfTask(ws, t.id);
                                                return (
                                                    <div 
                                                        key={t.id}
                                                        draggable
                                                        onDragStart={(e) => onDragStart(e, t)}
                                                        onClick={(e) => onTaskClick(e, t)}
                                                        className={`text-[10px] px-1 py-0.5 rounded truncate border cursor-pointer hover:opacity-80 ${getTaskColor(t, listIdx)}`}
                                                        title={`${t._listName}: ${t.text} (${t._assignee})`}
                                                    >
                                                        <span className="font-bold mr-1">{t._listName}:</span>
                                                        {t.text}
                                                        <span className="opacity-75 ml-1">({t._assignee})</span>
                                                    </div>
                                                )
                                            })}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ))}
                </div>
            </div>
        );
    };

    const renderWeekView = () => {
        const weekDates = getWeekDates(date);
        return (
            <div className="flex-grow flex flex-col overflow-hidden">
                <div className="grid grid-cols-7 gap-px bg-slate-200 border-b border-slate-200">
                    {weekDates.map(d => (
                        <div key={d.toString()} className={`bg-white py-2 text-center ${isSameDay(d, today) ? 'bg-yellow-50' : ''}`}>
                            <div className="text-xs text-slate-500 font-medium">{d.toLocaleDateString('default', { weekday: 'short' })}</div>
                            <div className={`text-sm font-bold ${isSameDay(d, today) ? 'text-indigo-600' : 'text-slate-800'}`}>{d.getDate()}</div>
                        </div>
                    ))}
                </div>
                <div className="flex-grow overflow-y-auto bg-slate-100 grid grid-cols-7 gap-px h-full">
                     {weekDates.map(day => {
                         const dateKey = fmt(day);
                         const tasks = tasksByDate[dateKey] || [];
                         const activeLists = listSpans.filter(l => dateKey >= l.startDate && dateKey <= l.endDate);

                         return (
                             <div 
                                key={dateKey}
                                onDragOver={(e) => e.preventDefault()}
                                onDrop={(e) => { e.preventDefault(); onDropOnDate(dateKey); }}
                                className="bg-white p-2 flex flex-col gap-2 min-h-full hover:bg-slate-50"
                             >
                                 {activeLists.map(l => (
                                     <div key={l.id} className="text-[10px] bg-orange-500 text-white px-1.5 py-0.5 rounded shadow-sm font-medium">
                                         {l.name}
                                     </div>
                                 ))}
                                 {tasks.map(t => {
                                     const ws = workspaces.find(w => w.id === t._workspaceId);
                                     const listIdx = findListIndexOfTask(ws, t.id);
                                     return (
                                         <div 
                                             key={t.id}
                                             draggable
                                             onDragStart={(e) => onDragStart(e, t)}
                                             onClick={(e) => onTaskClick(e, t)}
                                             className={`text-xs px-2 py-1.5 rounded shadow-sm border cursor-pointer hover:shadow-md ${getTaskColor(t, listIdx)}`}
                                         >
                                             <div className="font-medium truncate">
                                                <span className="font-bold mr-1">{t._listName}:</span>
                                                {t.text}
                                                <span className="opacity-75 ml-1">({t._assignee})</span>
                                             </div>
                                             {t.recurrence && <div className="text-[10px] flex items-center gap-1 mt-1"><RefreshCw size={8}/> Recurring</div>}
                                         </div>
                                     );
                                 })}
                             </div>
                         )
                     })}
                </div>
            </div>
        );
    };

    const renderTodayView = () => {
        const dateKey = fmt(date); // Should be today if not navigated
        const tasks = tasksByDate[dateKey] || [];
        const activeLists = listSpans.filter(l => dateKey >= l.startDate && dateKey <= l.endDate);

        return (
            <div className="flex-grow p-6 overflow-y-auto bg-slate-50">
                <div className="max-w-4xl mx-auto space-y-6">
                    {/* Active Phases */}
                    {activeLists.length > 0 && (
                        <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded shadow-sm">
                            <h3 className="font-bold text-orange-800 mb-2">Active Lists / Phases</h3>
                            <div className="flex flex-wrap gap-2">
                                {activeLists.map(l => (
                                    <span key={l.id} className="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-sm">
                                        {l.name} ({l.startDate} - {l.endDate})
                                    </span>
                                ))}
                            </div>
                        </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Task List */}
                        <div className="bg-white rounded-xl shadow p-4">
                            <h3 className="text-lg font-bold text-slate-800 border-b pb-2 mb-4">Scheduled for {date.toLocaleDateString()}</h3>
                            {tasks.length === 0 ? <p className="text-slate-400 italic">No tasks scheduled.</p> : (
                                <div className="space-y-3">
                                    {tasks.map(t => {
                                         const ws = workspaces.find(w => w.id === t._workspaceId);
                                         const listIdx = findListIndexOfTask(ws, t.id);
                                        return (
                                            <div 
                                                key={t.id} 
                                                onClick={(e) => onTaskClick(e, t)}
                                                className="flex items-start gap-3 p-3 rounded-lg border hover:shadow-md transition-all bg-white cursor-pointer"
                                            >
                                                <input 
                                                    type="checkbox" 
                                                    checked={t.completed} 
                                                    onChange={(e) => {
                                                        e.stopPropagation();
                                                        handlers.onUpdateTask(t._listId, t.id, { completed: !t.completed });
                                                    }}
                                                    className="mt-1 w-5 h-5 text-indigo-600 rounded" 
                                                />
                                                <div className="flex-grow">
                                                    <div className={`font-medium ${t.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                                                        <span className="font-bold mr-1">{t._listName}:</span>
                                                        {t.text}
                                                        <span className="opacity-75 ml-1">({t._assignee})</span>
                                                    </div>
                                                    <div className="text-xs text-slate-500 mt-1">{t._workspaceName}</div>
                                                </div>
                                                <div className={`w-2 h-full self-stretch rounded-full ${LIST_COLORS[listIdx % LIST_COLORS.length]}`}></div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>

                        {/* Stats / Quick Schedule */}
                        <div className="space-y-6">
                             <div className="bg-white rounded-xl shadow p-4">
                                <h3 className="text-lg font-bold text-slate-800 border-b pb-2 mb-4">Quick Stats</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-blue-50 p-4 rounded-lg">
                                        <div className="text-2xl font-bold text-blue-700">{tasks.length}</div>
                                        <div className="text-sm text-blue-600">Tasks on Date</div>
                                    </div>
                                    <div className="bg-green-50 p-4 rounded-lg">
                                        <div className="text-2xl font-bold text-green-700">{tasks.filter(t => t.completed).length}</div>
                                        <div className="text-sm text-green-600">Completed</div>
                                    </div>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    // --- Main Render ---
    const monthName = date.toLocaleString('default', { month: 'long', year: 'numeric' });
    const changeDate = (delta: number) => {
        const d = new Date(date);
        if (viewMode === 'week') d.setDate(d.getDate() + (delta * 7));
        else if (viewMode === 'today') d.setDate(d.getDate() + delta);
        else d.setMonth(d.getMonth() + delta);
        setDate(d);
    };
    
    // Handle manual date change from input
    const onDateInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if(e.target.value) setDate(new Date(e.target.value));
    };

    return (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 h-full flex flex-col overflow-hidden">
            {/* Toolbar */}
            <div className="p-4 border-b border-slate-200 flex flex-wrap gap-4 justify-between items-center bg-white z-10">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                         {viewMode === 'today' ? (
                             <div className="flex items-center gap-2 bg-slate-100 rounded-lg p-1 px-2">
                                <CalendarIcon size={18} className="text-indigo-600"/>
                                <input 
                                    type="date" 
                                    value={fmt(date)} 
                                    onChange={onDateInputChange}
                                    className="bg-transparent font-bold font-heading text-xl text-indigo-800 outline-none border-none cursor-pointer"
                                />
                             </div>
                         ) : (
                             <h2 className="text-2xl font-bold font-heading text-indigo-800 min-w-[150px]">{monthName}</h2>
                         )}
                    </div>

                    <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
                        <button onClick={() => changeDate(-1)} className="p-1 hover:bg-white rounded shadow-sm"><ChevronLeft size={20}/></button>
                        <button onClick={() => setDate(new Date())} className="px-2 text-xs font-bold text-slate-600 hover:text-indigo-600">Today</button>
                        <button onClick={() => changeDate(1)} className="p-1 hover:bg-white rounded shadow-sm"><ChevronRight size={20}/></button>
                    </div>
                </div>
                
                <div className="flex gap-3 text-sm">
                    <div className="flex items-center gap-2">
                        <span className="text-slate-500 font-medium">Show:</span>
                        <select value={filter} onChange={(e) => setFilter(e.target.value as any)} className="border rounded px-2 py-1 outline-none focus:ring-1 focus:ring-indigo-500">
                            <option value="active">Active Workspace</option>
                            <option value="all">All Workspaces</option>
                        </select>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-slate-500 font-medium">Filter:</span>
                        <select value={assigneeFilter} onChange={(e) => setAssigneeFilter(e.target.value)} className="border rounded px-2 py-1 outline-none focus:ring-1 focus:ring-indigo-500 min-w-[120px]">
                            <option value="all">All Assignees</option>
                            <option value="Unassigned">Unassigned</option>
                            {assignees.map(a => <option key={a} value={a}>{a}</option>)}
                        </select>
                    </div>
                </div>
            </div>

            <div className="flex flex-grow overflow-hidden">
                {viewMode === 'calendar' && renderMonthView()}
                {viewMode === 'week' && renderWeekView()}
                {viewMode === 'today' && renderTodayView()}
                {renderSidebar()}
            </div>
        </div>
    );
};

export default CalendarView;
