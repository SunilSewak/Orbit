
import React, { useState, useRef, useEffect } from 'react';
import { Task, ChecklistItem } from '../types';
import { 
    Trash2, ChevronDown, ChevronRight, User, Calendar, 
    RefreshCw, CheckSquare, Plus, Paperclip, File as FileIcon, Image as ImageIcon, Copy
} from 'lucide-react';
import { formatRecurrenceText } from '../utils/helpers';

interface TaskItemProps {
    task: Task;
    listId: string;
    level: number;
    assignees: string[];
    handlers: any;
    isDragging: boolean;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, listId, level, assignees, handlers, isDragging }) => {
    const [text, setText] = useState(task.text);
    const [dropIndicator, setDropIndicator] = useState<'top' | 'bottom' | 'child' | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Auto-resize textarea height
    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
        }
    }, [text, task.collapsed]); // Re-adjust if text changes or visibility might shift

    const isOverdue = task.dueDate && new Date(task.dueDate + "T00:00:00") < new Date() && !task.completed;
    const checklistProgress = task.checklist.length > 0 
        ? (task.checklist.filter(i => i.completed).length / task.checklist.length) * 100 
        : 0;

    const levelStyles: Record<number, { content: string, text: string }> = {
        1: { content: "border-l-4 border-red-500 bg-red-50/50", text: "text-base font-bold text-slate-800" },
        2: { content: "ml-4 border-l-4 border-blue-500 bg-blue-50/50", text: "text-sm font-semibold text-slate-700" },
        3: { content: "ml-8 border-l-4 border-green-500 bg-green-50/50", text: "text-xs italic text-slate-600" },
    };
    const currentStyle = levelStyles[level] || levelStyles[3];

    // Drag handlers
    const handleDragStart = (e: React.DragEvent) => {
        handlers.onTaskDragStart(e, { listId, taskId: task.id });
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (!handlers.draggedTaskInfo || handlers.draggedTaskInfo.taskId === task.id) return;

        const rect = e.currentTarget.getBoundingClientRect();
        const dropY = e.clientY - rect.top;
        const height = rect.height;

        if (dropY < height * 0.25) setDropIndicator('top');
        else if (dropY > height * 0.75) setDropIndicator('bottom');
        else setDropIndicator(level < 3 ? 'child' : 'bottom');
    };

    const handleDrop = (e: React.DragEvent) => {
        handlers.onTaskDrop(e, { listId, taskId: task.id });
        setDropIndicator(null);
    };

    return (
        <li 
            draggable 
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            onDragLeave={() => setDropIndicator(null)}
            onDrop={handleDrop}
            className={`relative flex flex-col group ${currentStyle.content} rounded-r-lg mb-3 transition-all duration-300 ${isDragging ? 'opacity-50 border-2 border-dashed border-indigo-500' : ''}`}
        >
            {dropIndicator === 'top' && <div className="absolute -top-1 left-4 right-0 h-1.5 bg-indigo-500 z-10 rounded-full" />}
            {dropIndicator === 'bottom' && <div className="absolute -bottom-1 left-4 right-0 h-1.5 bg-indigo-500 z-10 rounded-full" />}
            
            <div className={`flex items-start p-2 rounded-lg gap-2 transition-all ${task.completed ? 'opacity-60' : ''} ${isOverdue ? 'bg-red-100' : ''} ${dropIndicator === 'child' ? 'ring-2 ring-indigo-500' : ''}`}>
                <div className="flex flex-col items-center gap-2 pt-1">
                    <input 
                        type="checkbox" 
                        checked={task.completed} 
                        onChange={() => handlers.onUpdateTask(listId, task.id, { completed: !task.completed })}
                        className="w-5 h-5 text-indigo-600 rounded cursor-pointer" 
                    />
                </div>

                <div className="flex-grow min-w-0">
                    <textarea 
                        ref={textareaRef}
                        value={text} 
                        onChange={(e) => setText(e.target.value)}
                        onBlur={() => { if(text !== task.text) handlers.onUpdateTask(listId, task.id, { text }); }}
                        rows={1}
                        className={`w-full bg-transparent outline-none resize-none overflow-hidden focus:bg-white focus:ring-1 focus:ring-indigo-300 rounded px-1 ${currentStyle.text} ${task.completed ? 'line-through text-slate-500' : ''}`} 
                    />
                    
                    {/* Meta Controls */}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-xs text-slate-600">
                        <div className="flex items-center gap-1">
                            <User size={12} />
                            <select 
                                value={task.assignee || ''} 
                                onChange={(e) => handlers.onUpdateTask(listId, task.id, { assignee: e.target.value })}
                                className="bg-transparent outline-none max-w-[100px] cursor-pointer"
                            >
                                <option value="">Unassigned</option>
                                {assignees.map(a => <option key={a} value={a}>{a}</option>)}
                            </select>
                        </div>
                        <div className="flex items-center gap-1">
                            <Calendar size={12} />
                            <input 
                                type="date" 
                                value={task.dueDate || ''} 
                                onChange={(e) => handlers.onUpdateTask(listId, task.id, { dueDate: e.target.value })}
                                className="bg-transparent outline-none cursor-pointer"
                            />
                        </div>
                        {task.recurrence && (
                            <div className="flex items-center gap-1 bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full" title={formatRecurrenceText(task.recurrence)}>
                                <RefreshCw size={10} />
                                <span className="font-semibold">{formatRecurrenceText(task.recurrence).split(' ')[0]}</span>
                            </div>
                        )}
                    </div>

                    {/* Progress Bar */}
                    {task.checklist.length > 0 && (
                        <div className="mt-2">
                            <div className="flex justify-between text-[10px] text-slate-500 mb-0.5">
                                <span className="font-semibold">Checklist</span>
                                <span>{task.checklist.filter(i => i.completed).length}/{task.checklist.length}</span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-1.5">
                                <div className="bg-indigo-500 h-1.5 rounded-full transition-all" style={{ width: `${checklistProgress}%` }}></div>
                            </div>
                        </div>
                    )}

                    {/* Attachments */}
                    {task.attachments && task.attachments.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-2">
                            {task.attachments.map(att => (
                                <div key={att.id} className="flex items-center gap-2 bg-slate-100 px-2 py-1 rounded border shadow-sm text-xs max-w-full group/att">
                                    {att.type.startsWith('image/') ? <ImageIcon size={12} className="text-indigo-500"/> : <FileIcon size={12} className="text-slate-500"/>}
                                    <button 
                                        onClick={() => handlers.onPreviewAttachment(att)} 
                                        className="truncate hover:text-indigo-600 max-w-[100px] text-left"
                                        title={att.name}
                                    >{att.name}</button>
                                    <button onClick={() => handlers.onDeleteAttachment(listId, task.id, att.id)} className="text-red-400 hover:text-red-600 opacity-0 group-hover/att:opacity-100 transition-opacity">
                                        <Trash2 size={10} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Hover Actions */}
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity self-start bg-white/50 rounded-lg p-1">
                    <input 
                        type="file" 
                        ref={fileInputRef} 
                        className="hidden" 
                        accept=".jpg,.jpeg,.png,.gif,.txt,.pdf"
                        onChange={(e) => {
                            if(e.target.files?.[0]) handlers.onAttachFile(listId, task.id, e.target.files[0]);
                        }} 
                    />
                    <button onClick={() => fileInputRef.current?.click()} className="p-1 hover:bg-slate-200 rounded text-slate-500" title="Attach File"><Paperclip size={14}/></button>
                    <button onClick={() => handlers.onPasteAttachment(listId, task.id)} className="p-1 hover:bg-slate-200 rounded text-slate-500" title="Paste Image from Clipboard"><Copy size={14}/></button>
                    <button onClick={() => handlers.onShowRecurrencePopup(task, listId)} className={`p-1 hover:bg-slate-200 rounded ${task.recurrence ? 'text-purple-600' : 'text-slate-500'}`} title={task.recurrence ? formatRecurrenceText(task.recurrence) : "Set Recurrence"}><RefreshCw size={14}/></button>
                    <button onClick={() => handlers.onAddChecklistItem(listId, task.id)} className="p-1 hover:bg-slate-200 rounded text-slate-500" title="Add Checklist"><CheckSquare size={14}/></button>
                    {level < 3 && <button onClick={() => handlers.onAddSubtask(listId, task.id)} className="p-1 hover:bg-slate-200 rounded text-slate-500" title="Add Subtask"><Plus size={14}/></button>}
                    <button onClick={() => handlers.onDeleteTask(listId, task.id)} className="p-1 hover:bg-red-100 text-red-500 rounded" title="Delete Task"><Trash2 size={14}/></button>
                    {task.subtasks.length > 0 && (
                        <button 
                            onClick={() => handlers.onUpdateTask(listId, task.id, { collapsed: !task.collapsed })} 
                            className="p-1 hover:bg-slate-200 rounded text-slate-500 transition-transform duration-200"
                            style={{ transform: task.collapsed ? 'rotate(-90deg)' : 'rotate(0)' }}
                        >
                            <ChevronDown size={14}/>
                        </button>
                    )}
                </div>
            </div>

            {/* Checklist Render */}
            {task.checklist.length > 0 && !task.collapsed && (
                <div className="px-10 pb-2 space-y-1">
                    {task.checklist.map(item => (
                        <div key={item.id} className="flex items-center gap-2 group/check">
                            <input 
                                type="checkbox" 
                                checked={item.completed}
                                onChange={() => handlers.onToggleChecklistItem(listId, task.id, item.id)}
                                className="w-3 h-3 text-indigo-600 rounded-sm cursor-pointer"
                            />
                            <input 
                                value={item.text}
                                onChange={(e) => handlers.onUpdateChecklistItem(listId, task.id, item.id, { text: e.target.value })}
                                className={`flex-grow bg-transparent text-xs border-b border-transparent focus:border-indigo-300 outline-none ${item.completed ? 'line-through text-slate-400' : ''}`}
                            />
                            <button onClick={() => handlers.onDeleteChecklistItem(listId, task.id, item.id)} className="opacity-0 group-hover/check:opacity-100 text-red-400 hover:text-red-600">
                                <Trash2 size={10} />
                            </button>
                        </div>
                    ))}
                    <button onClick={() => handlers.onAddChecklistItem(listId, task.id)} className="text-[10px] text-indigo-600 font-bold hover:underline ml-5">+ Add item</button>
                </div>
            )}

            {/* Recursive Subtasks */}
            {!task.collapsed && task.subtasks.length > 0 && (
                <ul className="mt-1 transition-all duration-300">
                    {task.subtasks.map(subtask => (
                        <TaskItem 
                            key={subtask.id} 
                            task={subtask} 
                            listId={listId} 
                            level={level + 1} 
                            assignees={assignees} 
                            handlers={handlers} 
                            isDragging={handlers.draggedTaskInfo?.taskId === subtask.id}
                        />
                    ))}
                </ul>
            )}
        </li>
    );
};

export default TaskItem;
