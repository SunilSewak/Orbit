
import React from 'react';
import { Workspace, Task, List, FilterState } from '../types';
import TaskItem from './TaskItem';
import { isTaskVisible, sortTasks } from '../utils/helpers';
import { Plus, Trash2, User, Save } from 'lucide-react';

interface ListColumnProps {
    list: List;
    assignees: string[];
    filters: FilterState;
    sortOption: string;
    handlers: any;
}

const ListColumn: React.FC<ListColumnProps> = ({ list, assignees, filters, sortOption, handlers }) => {
    const visibleTasks = sortTasks(list.tasks.filter(t => isTaskVisible(t, list, filters)), sortOption);

    return (
        <div className="w-[400px] flex-shrink-0 flex flex-col max-h-full bg-white rounded-xl shadow-sm border border-slate-200">
            {/* List Header */}
            <div className="p-4 border-b border-slate-100">
                <div className="flex items-center justify-between mb-2">
                    <input 
                        value={list.name} 
                        onChange={(e) => handlers.onUpdateList(list.id, { name: e.target.value })}
                        className="font-bold text-lg text-slate-700 bg-transparent outline-none w-full focus:ring-1 focus:ring-indigo-200 rounded px-1"
                    />
                    <button onClick={() => handlers.onDeleteList(list.id)} className="text-slate-400 hover:text-red-500 p-1 rounded hover:bg-red-50 transition-colors">
                        <Trash2 size={16} />
                    </button>
                </div>
                <div className="flex gap-2 text-xs text-slate-500 mb-3">
                    <div className="flex items-center bg-slate-100 px-2 py-1 rounded w-full">
                        <User size={12} className="mr-1"/>
                        <select 
                            value={list.assignee || ''} 
                            onChange={(e) => handlers.onUpdateList(list.id, { assignee: e.target.value })}
                            className="bg-transparent outline-none w-full cursor-pointer"
                        >
                            <option value="">Team</option>
                            {assignees.map(a => <option key={a} value={a}>{a}</option>)}
                        </select>
                    </div>
                </div>
                <div className="flex gap-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                    <div className="flex-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">From</label>
                        <input 
                            type="date" 
                            value={list.startDate || ''} 
                            onChange={(e) => handlers.onUpdateList(list.id, { startDate: e.target.value })}
                            className="w-full text-xs border border-slate-200 rounded px-1 py-0.5 bg-white focus:border-indigo-300 outline-none"
                        />
                    </div>
                    <div className="flex-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">To</label>
                        <input 
                            type="date" 
                            value={list.endDate || ''} 
                            onChange={(e) => handlers.onUpdateList(list.id, { endDate: e.target.value })}
                            className="w-full text-xs border border-slate-200 rounded px-1 py-0.5 bg-white focus:border-indigo-300 outline-none"
                        />
                    </div>
                </div>
            </div>

            {/* Tasks List */}
            <ul className="flex-grow overflow-y-auto p-3 space-y-2 min-h-[100px]">
                {visibleTasks.map(task => (
                    <TaskItem 
                        key={task.id}
                        task={task}
                        listId={list.id}
                        level={1}
                        assignees={assignees}
                        handlers={handlers}
                        isDragging={handlers.draggedTaskInfo?.taskId === task.id}
                    />
                ))}
            </ul>

            <button 
                onClick={() => handlers.onAddTask(list.id)}
                className="m-3 p-2 flex items-center justify-center gap-2 text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-sm font-semibold transition-colors"
            >
                <Plus size={16} /> Add Task
            </button>
        </div>
    );
};

interface BoardProps {
    workspace: Workspace;
    assignees: string[];
    filters: FilterState;
    sortOption: string;
    handlers: any;
}

const Board: React.FC<BoardProps> = ({ workspace, assignees, filters, sortOption, handlers }) => {
    return (
        <div className="flex flex-col h-full bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
            {/* Workspace Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white z-10">
                <input 
                    value={workspace.name} 
                    onChange={(e) => handlers.onUpdateWorkspace(workspace.id, { name: e.target.value })}
                    className="text-2xl font-bold font-heading text-slate-800 bg-transparent outline-none focus:ring-2 focus:ring-indigo-100 rounded px-2 w-1/2"
                />
                <div className="flex gap-2">
                    <button 
                        onClick={() => handlers.onAddList(workspace.id)} 
                        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 text-sm font-semibold transition-colors"
                    >
                        <Plus size={16} /> Add List
                    </button>
                    <button 
                        onClick={() => handlers.onSaveAsTemplate(workspace.id)}
                        className="flex items-center gap-2 px-3 py-1.5 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 text-sm font-semibold transition-colors"
                    >
                        <Save size={16} /> Save Workspace
                    </button>
                </div>
            </div>

            {/* Lists Container */}
            <div className="flex-grow flex gap-6 overflow-x-auto p-6 bg-slate-50 items-start">
                {workspace.lists.map(list => (
                    <ListColumn 
                        key={list.id} 
                        list={list} 
                        assignees={assignees} 
                        filters={filters} 
                        sortOption={sortOption} 
                        handlers={handlers} 
                    />
                ))}
            </div>
        </div>
    );
};

export default Board;
