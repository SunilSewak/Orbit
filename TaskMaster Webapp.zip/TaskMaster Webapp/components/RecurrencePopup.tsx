import React, { useState } from 'react';
import { Task, Recurrence } from '../types';

interface RecurrencePopupProps {
    task: Task;
    onSave: (recurrence: Recurrence | null) => void;
    onClose: () => void;
}

const RecurrencePopup: React.FC<RecurrencePopupProps> = ({ task, onSave, onClose }) => {
    const [recurrence, setRecurrence] = useState<Partial<Recurrence>>(task.recurrence || {});

    const handleSave = () => {
        let updated: Recurrence | null = null;
        if (recurrence.type) {
            updated = {
                type: recurrence.type,
                interval: Math.max(1, recurrence.interval || 1),
                daysOfWeek: recurrence.daysOfWeek,
                daysOfMonth: recurrence.daysOfMonth,
                until: recurrence.until,
                count: recurrence.count
            };
        }
        onSave(updated);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-[400px] shadow-xl space-y-4">
                <h3 className="text-xl font-bold text-slate-800 font-heading">Set Recurrence</h3>

                <div>
                    <label className="block font-semibold mb-2 text-slate-700">Type</label>
                    <select
                        value={recurrence.type || ''}
                        onChange={(e) => {
                            const val = e.target.value;
                            if (!val) setRecurrence({});
                            else setRecurrence({ ...recurrence, type: val as any, interval: recurrence.interval || 1 });
                        }}
                        className="w-full border border-slate-300 p-2 rounded focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                        <option value="">No Recurrence</option>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                    </select>
                </div>

                {recurrence.type && (
                    <div className="space-y-4">
                        <div>
                            <label className="block font-semibold mb-2 text-slate-700">Interval</label>
                            <input
                                type="number"
                                min={1}
                                value={recurrence.interval || 1}
                                onChange={(e) => setRecurrence({ ...recurrence, interval: parseInt(e.target.value) || 1 })}
                                className="w-full border border-slate-300 p-2 rounded"
                            />
                        </div>

                        {recurrence.type === 'weekly' && (
                            <div>
                                <label className="block font-semibold mb-2 text-slate-700">Days of Week</label>
                                <div className="flex flex-wrap gap-2">
                                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, idx) => (
                                        <button
                                            key={day}
                                            type="button"
                                            onClick={() => {
                                                const current = recurrence.daysOfWeek || [];
                                                const newDays = current.includes(idx) ? current.filter(d => d !== idx) : [...current, idx];
                                                setRecurrence({ ...recurrence, daysOfWeek: newDays });
                                            }}
                                            className={`px-3 py-1 rounded text-sm ${
                                                (recurrence.daysOfWeek || []).includes(idx)
                                                    ? 'bg-indigo-600 text-white'
                                                    : 'bg-slate-200 text-slate-700'
                                            }`}
                                        >
                                            {day}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div>
                            <label className="block font-semibold mb-2 text-slate-700">End Date (Optional)</label>
                            <input
                                type="date"
                                value={recurrence.until || ''}
                                onChange={(e) => setRecurrence({ ...recurrence, until: e.target.value || undefined })}
                                className="w-full border border-slate-300 p-2 rounded"
                            />
                        </div>
                    </div>
                )}

                <div className="flex justify-end gap-2 pt-4">
                    <button onClick={onClose} className="px-4 py-2 bg-slate-200 rounded-lg hover:bg-slate-300 transition-colors">Cancel</button>
                    <button onClick={handleSave} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">Save</button>
                </div>
            </div>
        </div>
    );
};

export default RecurrencePopup;