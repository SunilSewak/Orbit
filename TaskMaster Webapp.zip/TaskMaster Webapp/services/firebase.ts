
import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc, initializeFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCk-Q4hgZKimw78UMPJeVVgMnYtiJS0bxI",
  authDomain: "mytodoapp-bf6d9.firebaseapp.com",
  projectId: "mytodoapp-bf6d9",
  storageBucket: "mytodoapp-bf6d9.firebasestorage.app",
  messagingSenderId: "39415865882",
  appId: "1:39415865882:web:a4b9d117fa8e4618eea7a3"
};

const app = initializeApp(firebaseConfig);
// Initialize Firestore with settings to ignore undefined properties
export const db = initializeFirestore(app, {
    ignoreUndefinedProperties: true
});
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = async () => {
    try {
        await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
        // Suppress console error for known configuration issues to avoid confusion
        const code = error?.code || '';
        if (code !== 'auth/unauthorized-domain' && 
            code !== 'auth/api-key-not-valid' && 
            code !== 'auth/popup-closed-by-user') {
            console.error("Login failed", error);
        }
        throw error;
    }
};

export const logout = async () => {
    await signOut(auth);
};

export const loadUserData = async (userId: string) => {
    try {
        const docRef = doc(db, "appData", userId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            return docSnap.data();
        }
        return null;
    } catch (error) {
        console.error("Error loading data:", error);
        throw error;
    }
};

export const saveUserData = async (userId: string, data: any) => {
    try {
        await setDoc(doc(db, "appData", userId), {
            ...data,
            lastUpdated: new Date().toISOString()
        });
        return true;
    } catch (error) {
        console.error("Error saving data:", error);
        throw error;
    }
};
